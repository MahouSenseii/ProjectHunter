#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "AbilitySystemInterface.h"
#include "Core/Logging/ProjectHunterLogMacros.h"
#include "Character/ALSCharacter.h"
#include "Character/Library/PHCharacterLog.h"
#include "Combat/Library/Structs/CombatStructs.h"
#include "AbilitySystem/HunterAbilitySystemComponent.h"
#include "AbilitySystem/PHAbilitySet.h"
#include "PHBaseCharacter.generated.h"

struct FGameplayAbilitySpecHandle;

class UAbilitySystemComponent;
class UHunterAttributeSet;
class UHunterAbilitySystemComponent;
class UCharacterProgressionManager;
class UCombatManager;
class UEquipmentManager;
class UInventoryManager;
class UEquipmentPresentationComponent;
class UHunterDamagePopupPresentationComponent;
class UCharacterSystemCoordinatorComponent;
class UStatsManager;
class UTagManager;
class UCombatStatusEffectApplier;
class UBaseStatsData;
class UGameplayEffect;
class UGameplayAbility;
class UPHCharacterMovementComponent;
struct FOnAttributeChangeData;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnDeath, APHBaseCharacter*, DeadCharacter, AActor*, KillerActor);

UCLASS(Abstract)
class ALS_PROJECTHUNTER_API APHBaseCharacter : public AALSCharacter, public IAbilitySystemInterface
{
	GENERATED_BODY()

public:
	APHBaseCharacter(const FObjectInitializer& ObjectInitializer);

	virtual void PostInitializeComponents() override;
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;
	virtual void PossessedBy(AController* NewController) override;
	virtual void ForwardMovementAction_Implementation(float Value) override;
	virtual void RightMovementAction_Implementation(float Value) override;
	virtual void JumpAction_Implementation(bool bValue) override;
	virtual void SprintAction_Implementation(bool bValue) override;
	virtual FVector GetFootIKSurfaceNormal_Implementation() const override;
	virtual FALSWallTransitionData GetWallTransitionData_Implementation() const override;
	virtual void OnRep_PlayerState() override;
	virtual void OnRep_Controller() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UFUNCTION(BlueprintPure, Category = "Movement|Wall Traversal")
	UPHCharacterMovementComponent* GetPHMovementComponent() const;

	UFUNCTION(BlueprintCallable, Category = "Movement|Wall Traversal")
	bool TryStartWallTraversal();

	UFUNCTION(BlueprintCallable, Category = "Movement|Wall Traversal")
	void StopWallTraversal();

	/**
	 * Optional AnimNotify hook. The movement component also completes after its
	 * configured duration, so dedicated servers do not depend on animation ticking.
	 */
	UFUNCTION(BlueprintCallable, Category = "Movement|Wall Traversal")
	void CompleteWallToGroundTransition();

	UFUNCTION(BlueprintPure, Category = "Movement|Wall Traversal")
	bool IsWallTraversing() const;

	UFUNCTION(BlueprintPure, Category = "Movement|Wall Traversal")
	bool IsWallRunning() const;

	UFUNCTION(BlueprintPure, Category = "Movement|Wall Traversal")
	bool IsWallClimbing() const;

	UFUNCTION(BlueprintPure, Category = "Movement|Wall Traversal")
	FRotator GetWallTraversalRotation() const;

	UFUNCTION(BlueprintPure, Category = "Movement|Stamina")
	bool IsStaminaExhausted() const;

	UFUNCTION(BlueprintPure, Category = "Movement|Stamina")
	bool CanUseStaminaMovement() const;

	UFUNCTION(BlueprintPure, Category = "Movement|Stamina")
	bool IsStaminaMovementInputHeld() const { return bStaminaMovementInputHeld; }

	void RefreshStaminaMovementInput();

	/**
	 * True while wall traversal is requested. ALS keeps sprint intent in
	 * DesiredGait, so that remains valid when sprint was pressed before jump.
	 */
	UFUNCTION(BlueprintPure, Category = "Movement|Wall Traversal")
	bool WantsWallTraversal() const
	{
		return bWallTraversalHeld || GetDesiredGait() == EALSGait::Sprinting;
	}

	/**
	 * Returns the weight used to select wall running, wall climbing, or rejection.
	 * Override in Blueprint when the final equipment/encumbrance calculation is ready.
	 */
	UFUNCTION(BlueprintNativeEvent, BlueprintPure, Category = "Movement|Wall Traversal|Weight")
	float GetWallTraversalWeight() const;
	virtual float GetWallTraversalWeight_Implementation() const;

	/**
	 * Converts weight into the requested ALS movement state.
	 * Return None to reject wall attachment.
	 */
	UFUNCTION(BlueprintNativeEvent, BlueprintPure, Category = "Movement|Wall Traversal|Weight")
	EALSMovementState SelectWallTraversalState(float CurrentWeight) const;
	virtual EALSMovementState SelectWallTraversalState_Implementation(float CurrentWeight) const;

	/** Called by wall physics when the surface ends; existing ALS mantle remains the owner. */
	bool TryWallTopMantle();


	/** Ability System Component - Handles all GAS functionality. Typed as the
	 *  concrete UHunterAbilitySystemComponent so its resource/regen/exhaustion
	 *  slots are exposed when the component is selected in a Blueprint. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Abilities", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<UHunterAbilitySystemComponent> AbilitySystemComponent;

	/** Main attribute set - All combat stats (Health, Damage, Resistances, etc.) */
	UPROPERTY(BlueprintReadWrite, meta = (AllowPrivateAccess = "true"))
	TObjectPtr<UHunterAttributeSet> AttributeSet;

	/** Progression Manager - XP, Level, Stat Points */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Progression", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<UCharacterProgressionManager> ProgressionManager;

	/** Equipment Component - Items, gear, inventory */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Equipment", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<UEquipmentManager> EquipmentManager;

	/**
	 * Inventory Component - the carried bag.
	 *
	 * Every system reaches this through FindComponentByClass<UInventoryManager>(),
	 * so it has to exist on the character or the whole inventory silently no-ops.
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Inventory", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<UInventoryManager> InventoryManager;

	/** Stats Manager - All stat queries and calculations */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Stats", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<UStatsManager> StatsManager;

	/** Tag Manager - Central runtime gameplay tag state for this character */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Tags", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<UTagManager> TagManager;


	/**
	 * Combat Manager - resolves all hit/damage interactions for this character.
	 * Weapons (and fists) report hits here; the manager owns the damage pipeline.
	 * Configure DamageApplicationGE and RecoveryApplicationGE in Blueprint defaults.
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Combat", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<UCombatManager> CombatManager;

	/**
	 * Equipment Presentation Component - owns visual weapon actors and mesh
	 * attachment. Bound to EquipmentManager::OnEquipmentChanged by the coordinator.
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Equipment", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<UEquipmentPresentationComponent> EquipmentPresentation;

	/** Local UI listener for resolved combat damage. Assign the popup widget Blueprint in character defaults. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Combat|Presentation", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<UHunterDamagePopupPresentationComponent> DamagePopupPresentation;

	/**
	 * Character System Coordinator - single point of cross-system listener wiring.
	 * PH-0.4: APHBaseCharacter is a composition root only; orchestration lives here.
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Coordinator", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<UCharacterSystemCoordinatorComponent> SystemCoordinator;


	virtual UAbilitySystemComponent* GetAbilitySystemComponent() const override
	{
		// Fast path: member pointer is valid (normal case).
		if (AbilitySystemComponent)
		{
			return AbilitySystemComponent;
		}

		// Safety net: the member was cleared, which happens when a Blueprint child
		// class adds a component with the same display name as the C++ CreateDefaultSubobject
		// ("AbilitySystemComponent"). UE5 evicts the C++ component from the TObjectPtr
		// during Blueprint component reconciliation, but the component object itself
		// survives on the actor. FindComponentByClass recovers it.
		//
		// Blueprint cleanup: open the Blueprint's Components panel, right-click the "Ability
		// System Component" entry, and if Delete is available it is Blueprint-added
		// and must be removed. The C++ CreateDefaultSubobject is the authoritative one.
		UHunterAbilitySystemComponent* FoundASC = FindComponentByClass<UHunterAbilitySystemComponent>();

		PH_LOG_WARNING(LogPHBaseCharacter, "GetAbilitySystemComponent recovered a null member pointer for Character=%s via ASC=%s. A Blueprint child class likely has a duplicate Ability System Component in its Components panel.", *GetName(), *GetNameSafe(FoundASC));

		return FoundASC;
	}

	UFUNCTION(BlueprintPure, Category = "Abilities")
	UHunterAttributeSet* GetAttributeSet() const
	{
		return AttributeSet;
	}

	UFUNCTION(BlueprintPure, Category = "Progression")
	UCharacterProgressionManager* GetProgressionManager() const
	{
		return ProgressionManager;
	}

	UFUNCTION(BlueprintPure, Category = "Equipment")
	UEquipmentManager* GetEquipmentManager() const
	{
		return EquipmentManager;
	}

	UFUNCTION(BlueprintPure, Category = "Inventory")
	UInventoryManager* GetInventoryManager() const
	{
		return InventoryManager;
	}



	UFUNCTION(BlueprintPure, Category = "Stats")
	UStatsManager* GetStatsManager() const
	{
		return StatsManager;
	}

	UFUNCTION(BlueprintPure, Category = "Tags")
	UTagManager* GetTagManager() const
	{
		return TagManager;
	}

	UFUNCTION(BlueprintPure, Category = "Combat")
	UCombatManager* GetCombatManager() const
	{
		return CombatManager;
	}

	/**
	 * CombatManager owns CombatStatus directly now (it is no longer a sibling
	 * character component); this forwards for existing callers. Defined in the
	 * .cpp because it needs UCombatManager's full type, not just the forward decl.
	 */
	UFUNCTION(BlueprintPure, Category = "Combat|Status")
	UCombatStatusEffectApplier* GetCombatStatusManager() const;

	UFUNCTION(BlueprintPure, Category = "Combat|Presentation")
	UHunterDamagePopupPresentationComponent* GetDamagePopupPresentation() const
	{
		return DamagePopupPresentation;
	}

	UFUNCTION(BlueprintPure, Category = "Combat|Status", meta = (DeprecatedFunction, DeprecationMessage = "Use GetCombatStatusManager."))
	UCombatStatusEffectApplier* GetDoTManager() const
	{
		return GetCombatStatusManager();
	}


	/** Character level (cached from ProgressionManager for convenience) */
	UPROPERTY(BlueprintReadOnly, Category = "Character")
	int32 CachedLevel = 1;

	/** Light characters can wall run. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Movement|Wall Traversal|Weight",
		meta = (ClampMin = "0.0"))
	float MaxWallRunningWeight = 30.0f;

	/** Medium characters climb; heavier characters cannot attach. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Movement|Wall Traversal|Weight",
		meta = (ClampMin = "0.0"))
	float MaxWallClimbingWeight = 70.0f;

	UPROPERTY(BlueprintReadOnly, Category = "Movement|Wall Traversal")
	bool bWallTraversalHeld = false;

	UPROPERTY(BlueprintReadOnly, Category = "Movement|Stamina")
	bool bStaminaMovementInputHeld = false;

	/** Is this character a player? */
	UFUNCTION(BlueprintPure, Category = "Character")
	virtual bool IsPlayer() const { return false; }

	/** Is this character an NPC? */
	UFUNCTION(BlueprintPure, Category = "Character")
	virtual bool IsNPC() const { return false; }



	/**
	 * Broadcast exactly once when this character dies.
	 *
	 * Blueprint death logic stays the orchestrator: when your BP decides the
	 * character is dead (ragdoll, montage, loot, etc.), call NotifyDeath(Killer)
	 * as one extra node. That single call is what lets C++ systems react -
	 * AMobManagerActor binds here for kill counts, OnMobDied, and pool recycling.
	 *
	 * Do not broadcast this delegate directly; NotifyDeath guards against
	 * double-fire and enforces server authority.
	 */
	UPROPERTY(BlueprintAssignable, Category = "Character|Death")
	FOnDeath OnDeath;

	/**
	 * Single entry point for declaring this character dead.
	 * Call from your Blueprint death event (server side). Safe to call multiple
	 * times - only the first call broadcasts OnDeath.
	 * @param Killer  The actor credited with the kill (may be null).
	 */
	UFUNCTION(BlueprintCallable, Category = "Character|Death", BlueprintAuthorityOnly)
	virtual void NotifyDeath(AActor* Killer);

	/** True once NotifyDeath has fired (until ResetDeathState, e.g. pool reuse). */
	UFUNCTION(BlueprintPure, Category = "Character|Death")
	bool IsDead() const { return bHasDied; }

	/**
	 * Clears the death latch so a pooled/recycled actor can die again.
	 * Called by AMobManagerActor::FinalizeSpawn and UMobPoolSubsystem::ResetMobState.
	 */
	UFUNCTION(BlueprintCallable, Category = "Character|Death")
	virtual void ResetDeathState() { bHasDied = false; }


	/** Get current level */
	UFUNCTION(BlueprintPure, Category = "Progression")
	int32 GetCharacterLevel() const;

	/** Get base XP reward (for when this character is killed) */
	UFUNCTION(BlueprintPure, Category = "Progression")
	virtual int64 GetXPReward() const;

	/** Multiplier applied to the base XP reward calculation. Override in subclasses or set in Blueprint. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Progression", meta = (ClampMin = "0.0"))
	float XPRewardMultiplier = 1.0f;

	/** Award XP to this character from killing another character */
	UFUNCTION(BlueprintCallable, Category = "Progression", BlueprintAuthorityOnly)
	void AwardExperienceFromKill(APHBaseCharacter* KilledCharacter);

	/** Get current health (delegates to StatsManager) */
	UFUNCTION(BlueprintPure, Category = "Combat")
	float GetHealth() const;

	/** Get max health (delegates to StatsManager) */
	UFUNCTION(BlueprintPure, Category = "Combat")
	float GetMaxHealth() const;

	/** Get health percent (delegates to StatsManager) */
	UFUNCTION(BlueprintPure, Category = "Combat")
	float GetHealthPercent() const;


	/**
	 * Called when health changes
	 */
	virtual void HandleHealthChanged(const FOnAttributeChangeData& Data);


	/** Lyra-style ability sets granted to this character on first ASC initialization. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Abilities")
	TArray<TObjectPtr<UPHAbilitySet>> DefaultAbilitySets;

	/** Legacy direct ability grants. Prefer DefaultAbilitySets for new abilities. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Abilities|Legacy")
	TArray<TSubclassOf<UGameplayAbility>> DefaultAbilities;

	/** Startup effects applied on spawn */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Abilities")
	TArray<TSubclassOf<UGameplayEffect>> StartupEffects;

	UFUNCTION(BlueprintCallable, Category = "Abilities")
	void GiveDefaultAbilities();

	UFUNCTION(BlueprintCallable, Category = "Abilities")
	void ApplyStartupEffects();

	UFUNCTION(BlueprintCallable, Category = "Abilities")
	void RemoveAllAbilities();



	/** Reinitialize base attributes from the data asset / startup GEs. */
	virtual void InitializeAttributes();

protected:
	virtual void OnMovementModeChanged(EMovementMode PrevMovementMode, uint8 PreviousCustomMode = 0) override;

	virtual void InitializeAbilitySystem();
	virtual void BindAttributeDelegates();
	virtual void OnAbilitySystemInitialized();
	bool EnsureAttributeSetRegisteredWithAbilitySystem();
	void ApplyStaminaMovementInput(bool bHeld, bool bSendServerRpc);

	UPROPERTY()
	bool bAbilitySystemInitialized = false;

	/** Death latch - set by NotifyDeath, cleared by ResetDeathState. */
	UPROPERTY(Transient)
	bool bHasDied = false;

	UPROPERTY()
	TArray<FGameplayAbilitySpecHandle> GrantedAbilityHandles;

	UPROPERTY()
	TArray<FPHAbilitySet_GrantedHandles> GrantedAbilitySetHandles;

	UFUNCTION(Server, Reliable)
	void ServerSetWallTraversalHeld(bool bHeld);

	UFUNCTION(Server, Reliable)
	void ServerCompleteWallToGroundTransition();

	float WallAttachRetryAccumulator = 0.0f;

	UPROPERTY(EditDefaultsOnly, Category = "Movement|Wall Traversal", meta = (ClampMin = "0.0"))
	float WallAttachRetryInterval = 0.05f;
};
